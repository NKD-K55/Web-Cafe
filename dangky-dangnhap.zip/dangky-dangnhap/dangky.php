<!DOCTYPE html>
<html lang="en">

    <head>

    <meta  http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href ="CSS/mystyle.css"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
    integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    </head>

    <body>
        <section style="background-image: url('img/bg_dk.jpg');" >
     
            <!--Nội Dung-->
            <div class="noi-dung">

                <div class="form">

                    <h2>Trang Đăng Kí</h2>

                    <form action="dangky.php" method = "post">
                        <div class="input-form">
                            <span>Tên Người Dùng</span>
                            <input class="nhap" type="text" name="username" value="" required >
                        </div>

                        <div class="input-form">
                            <span>Mật Khẩu</span>
                            <input class="nhap" type="password" name="password" value="" required >
                        </div>

                        <div class="input-form">
                            <span>Phonenumber</span>
                            <input class="nhap" type="text" name="phone" value="" required >
                        </div>

                        <div class="input-form">
                            <span>Email</span>
                            <input class="nhap" type="text" name="email" value="" required >
                        </div>

                        <div class="input-form"> 
                            <input class="nhap" type="submit" name="dangky" value="Đăng Ký">
                            
                        </div>
                        <?php require 'xuly_dangki.php';?> 
                    </form>
                </div>
            </div>


        </section>

    </body>

</html>